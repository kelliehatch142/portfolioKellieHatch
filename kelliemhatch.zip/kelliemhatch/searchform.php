<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">

    

    <label>

        

        

	<input type="search" class="search-field" placeholder="Search …" value="" name="s" title="Search for:" />

        

    </label>

    

	<input type="submit" class="btn" value="Search" />

        

</form>