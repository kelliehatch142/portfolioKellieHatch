<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<title>Kellie Hatch <?php wp_title (); ?> </title>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" type="image/x-icon" href="<?php echo get_template_directory_uri() ?>/images/favicon.ico" />
		<!--- STYLE SHEETS -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/style.css">
		<link href='https://fonts.googleapis.com/css?family=Raleway:600,300|Playfair+Display' rel='stylesheet' type='text/css'>
        <?php remove_filter( 'the_content', 'wpautop' ); ?>
		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	</head>
    <body>
		<header>
			<nav>
				<button class="nav-button">Toggle Navigation</button>
        <div class="mobileLogoWrapper"><img src="<?php echo get_template_directory_uri() ?>/images/logo-white.svg" class="mobileLogo show768" /></div>
					<?php wp_nav_menu(array('menu_class' => 'primary-nav centerText')); ?>
  			</nav> 
    		<div class="logoWrapper">
   				<a href="<?php echo site_url(); ?>"><img src="<?php echo get_template_directory_uri() ?>/images/logo-grey.svg" alt="Kellie Hatch logo" class="logo"></a>
   			</div>  
    </header>
    <main>