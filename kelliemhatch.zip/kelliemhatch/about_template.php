<?php 
/* 
Template Name: About Me Template
*/
?>
<?php get_header(); ?>
<style>
.aboutImage { background: linear-gradient( rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.9) ), url("<?php echo get_template_directory_uri() ?>/images/aboutHero.jpg"); background-size:cover; background-repeat:no-repeat; background-position:center bottom; padding-left:10px; padding-right:10px; }
.aboutImage1 { background-image:url("<?php echo get_template_directory_uri() ?>/images/about-img1.jpg"); background-position:center; background-size:cover; height:400px; }
.aboutImage1:after { content:""; display:block; height:0; padding-bottom:66.66667%; }
.aboutImage2 { background-image:url("<?php echo get_template_directory_uri() ?>/images/about-img2.jpg"); background-position:center; background-size:cover; height:400px; }
</style>
<div class="aboutImage paddingTop125">
        <div class="webHeroCopy centerText fadeIn">
          <h1 class="serif lineBlock">Building a better digital world</h1>
          <p class="largeTxt1 topSpacing">What’s it like to work with me? Try imagining a partner who has the heart of a developer, <br>the soul of an designer, and a vision to create an elegant interface and mobile enhanced product.

</p>
        </div>
      </div>
      <section class="maxWidth1000 ">
     
        <div class="grid">
            <div class="column width50 full475">
              <div class="backgroundWhite aboutCards topAboutCard">
                <h2 class="serif colorBlock">A <i>little</i> about me</h2>
                <p class="topSpacing">I am a web developer ninja located in Utah County and have worked in the industry for seven years. I design and create clean, eye-catching, interactive websites, blogs, and logos with a focus on user-friendly interfaces. I believe that a website must work beautifully on any device.</p>
                <p>I currently work for Ancestry as a Front End Developer. I work with their Production Marketing Team creating landing pages, emails, and overlays.</p>
              </div>
              <div class="aboutImage1 hide475"></div>
            </div>
            <div class="column width50 full475">
              <div class="aboutImage2"></div>
              <div class="backgroundWhite aboutCards">
                <h2 class="serif colorBlock"><i>Sometimes</i> I go outside</h2>
                <p class="topSpacing">I graduated from UVU with a degree in Internet Technologies in 2016.</p>
                <p>When I am not developing I love to wakesurf, cook, workout, and spend time with my boys.</p>
              </div>
            </div>
        </div>  
      </section>
      <div class="backgroundBlue aboutBackground width100"></div>
<?php get_footer(); ?>