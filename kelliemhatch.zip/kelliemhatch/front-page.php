
<?php get_header(); ?>
<style>
.heroImage { background-image: url("<?php echo get_template_directory_uri() ?>/images/heroHeader.jpg"); }
</style>
<div class="heroBanner maxWidth1000 homeHero">
        <div class="heroCopy width50 full767 fadeIn">
          <h1 class="serif">Welcome. Lets build something <i>awesome</i>.</h1>
          <p class="largeTxt1 topSpacing">I create beautiful websites and mobile UI designs providing my clients with pixel perfect results.</p>
          <a href="<?php echo site_url(); ?>/portfolio/" class="button blueButton topSpacing">View work</a>
          <a href="<?php echo site_url(); ?>/contact/" class="button secondaryButton leftSpacing15 topSpacing hide767">Contact</a>
        </div>
        <figure class="heroImage"><img src="<?php echo get_template_directory_uri() ?>/images/heroHeader3.png"></figure>
      </div>
      <section class="maxWidth1000 marginTop45">
        <div class="grid topSpacing">
          <div class="column width50 full475">
            <h2 class="serif colorBlock">I love making <br><i>great ideas</i> happen</h2>
          </div>
          <div class="column width50 full475">
            <p class="topSpacing">I believe that the devil is in the details and that the details can make or break a design. I would love to build something with you. Lets get started! <a href="<?php echo site_url(); ?>/about/">Learn more about me.</a></p>
          </div>
        </div>
        <div class="grid marginTop45 slideUp" id="recentProjectCards">
          <div class="column width50 full767">
			  <?php 
		$posts = get_posts(array(
			'numberposts'	=> 2,
			'post_type'		=> 'webdev',
		
			'order' => 'DESC',
		
		));
		if( $posts ): ?>	
			  
			
			<?php foreach( $posts as $post ): 
				setup_postdata( $post );	
				?>
			  <?php $image = get_field('hero_img'); ?>
				<style> #project<?php the_ID()  ?> .projectImg { background-image:url("<?php echo $image['url']; ?>"); position:relative; background-position:center; background-size:cover; } #project<?php the_ID()  ?> .projectImg:after {  content: "";  display: block;  height: 0;  padding-bottom: 54%; }</style>
			  	<a href="<?php the_permalink() ?>" id="project<?php the_ID()  ?>">
					<div class="projectImg rpSection">
                		<span class="projectOverlay blueOverlay"></span>
               			<h3 class="recentProjectTitle"><?php the_title(); ?></h3>
              		</div>
			  </a>
			  
			 
				
			<?php endforeach; ?>
			<?php wp_reset_postdata(); ?>
			<?php endif; ?>
			  
          </div>
          <div class="column width50 full767">
            <div class="grid">
				
				 <?php 
					$postsTwo = get_posts(array(
						'numberposts'	=> 2,
						'post_type'		=> 'webdev',
						'offset'        => 2,			
						'order' => 'DESC',

					));
					if( $postsTwo ): ?>	

						<?php foreach( $postsTwo as $post ): 
							setup_postdata( $post );	
							?>
						  <?php $image = get_field('hero_img'); ?>
							<style> #project<?php the_ID()  ?> .projectImg { background-image:url("<?php echo $image['url']; ?>"); position:relative; background-position:center; background-size: cover; } #project<?php the_ID()  ?> .projectImg:after {  content: "";  display: block;  height: 0;  padding-bottom: 72%; }</style>
				
				
							<div class="column width50">
								<a href="<?php the_permalink() ?>" id="project<?php the_ID()  ?>">
								  <div class="projectImg rpSection">
									<span class="projectOverlay blueOverlay"></span>
									<h3 class="recentProjectTitle"><?php the_title(); ?></h3>
								  </div>
								</a>
							  </div>
				


						<?php endforeach; ?>
						<?php wp_reset_postdata(); ?>
						<?php endif; ?>
				
		
            </div>
			  
			 <?php 
					$postsTwo = get_posts(array(
						'numberposts'	=> 1,
						'post_type'		=> 'webdev',
						'offset'        => 4,			
						'order' => 'DESC',

					));
					if( $postsTwo ): ?>	

						<?php foreach( $postsTwo as $post ): 
							setup_postdata( $post );	
							?>
						  <?php $image = get_field('hero_img'); ?>
							<style> #project<?php the_ID()  ?> .projectImg { background-image:url("<?php echo $image['url']; ?>"); position:relative; background-position:center; background-size: cover; } #project<?php the_ID()  ?> .projectImg:after {  content: "";  display: block;  height: 0;  padding-bottom: 72%; }</style>
				
			  
							 <a href="<?php the_permalink() ?>" id="project<?php the_ID()  ?>">
							  <div class="projectImg rpSection">
								<span class="projectOverlay blueOverlay"></span>
								<h3 class="recentProjectTitle"><?php the_title(); ?></h3>
							  </div>
							</a>


						<?php endforeach; ?>
						<?php wp_reset_postdata(); ?>
						<?php endif; ?>
          
          </div>
        </div>
        <a href="<?php echo site_url(); ?>/portfolio/" class="button centerButton">View Portfolio</a>
      </section>
      <section class="width100 backgroundBlue white marginTop45">
        <div class="maxWidth1000 sectionPadding">
          <h2 class="serif largeTxt3 centerText">Beautiful, innovative &amp; effective handcrafted designs &amp; websites.</h2>
          <p class="topSpacing15">I aim for only the very best results, and end with a product worthy of your name. I believe in honest, useful and intuitive design that helps solve business goals and makes it easy and delightful for the user to navigate and experience the website or app. I believe that a website should be easy to navigate no matter what device it is being viewed on. I believe that beautiful aesthetics that matches the brand- or campaign-story adds value and makes everything more enjoyable. </p>
          <a href="<?php echo site_url(); ?>/about/" class="button secondaryButton centerButton whiteSecButton">Learn more about me</a>
        </div>
      </section>

<?php get_footer(); ?>
