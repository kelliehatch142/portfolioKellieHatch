<?php get_header(); ?>
	<?php 
		$bgimage = get_field('hero_img');
		$deviceImage = get_field('website_on_device_img');
	?>
<style>
 .webProjectHero { background:linear-gradient( rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.9) ), url("<?php echo $bgimage['url']; ?>"); background-size:cover; background-repeat:no-repeat; background-position:center top;  min-height:400px; padding-left:10px; padding-right:10px; }
	.webProjectHero .heroCon { padding:250px 50px 300px; }
.webProjectComputer { background-image:url("<?php echo $deviceImage['url']; ?>"); background-size:contain; background-repeat:no-repeat; background-position:center bottom; max-width:1137px; }
.webProjectComputer:after { content:""; display:block; height:0; padding-bottom:82.47142%; }

</style>
<?php add_filter( 'the_content', 'wpautop' ); ?> 
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="webProjectHero width100">
        <div class="heroCon centerText fadeIn">
          <h1 class="serif lineBlock"><?php the_title(); ?></h1>
          <div class="largeTxt1 topSpacing width70 centerObject"><strong><?php the_content(); ?></strong></div>
        </div>
      </div>
      <section class="maxWidth1000 marginTop45">
        <div class="deviceWrapper">
          <div class="deviceBackground"></div>
          <div class="webProjectComputer width66 centerObject"></div>
        </div>
        <p class="marginTop45 width70 centerObject centerText"><?php the_field('bottom_text') ?></p>
        <a href="<?php the_field('link_to_site') ?>" class="button centerButton" target="_blank">View Site</a>
       
      </section> 
<?php endwhile; else: ?>
<?php endif; ?>
<?php get_footer(); ?>