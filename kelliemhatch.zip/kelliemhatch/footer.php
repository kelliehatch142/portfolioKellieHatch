 </main>
    <div id="footerWrapper" class="keepOpen backgroundDarkGrey topPadding">
      <footer class="maxWidth1000">
        <div class="grid footerTop">
          <div class="width50 full475 left">
            <h4 class="uppercase">Contact</h4>
            <a href="mailto:kelliehatch142@gmail.com" class="uppercase blue">kelliehatch142@gmail.com</a>
          </div>
          <div class="width50 full475 left">
			  
			  <div class="socialIconsCon">
				<a href="https://twitter.com/kelliehatch" target="_blank" class="c-link c-link--twitter c-tooltip" aria-label="Twitter">
					<svg class="c-icon"><use xlink:href="#icon--twitter"></use></svg>
				</a>
				<a href="https://www.facebook.com/kelliemhatch" target="_blank" class="c-link c-link--facebook c-tooltip" aria-label="Facebook">
					<svg class="c-icon"><use xlink:href="#icon--facebook"></use></svg>
				</a>
				<!-- <a href="#0" class="c-link c-link--instagram c-tooltip" aria-label="Instagram">
					<svg class="c-icon"><use xlink:href="#icon--instagram"></use></svg>
				</a> -->
				<a href="https://www.linkedin.com/in/hatchkellie" class="c-link c-link--linkedin c-tooltip" aria-label="LinkedIn">
					<svg class="c-icon"><use xlink:href="#icon--linkedin"></use></svg>
				</a>
			</div>
			  <svg style="display: none">
						    <symbol id="icon--facebook" viewBox="0 0 24 24">
						        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg>
						    </symbol>
						    <symbol id="icon--twitter" viewBox="0 0 24 24">
						        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/></svg>
						    </symbol>
				
						    <symbol id="icon--instagram" viewBox="0 0 24 24">
						        <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" />
						    </symbol>
						    <symbol id="icon--linkedin" viewBox="0 0 24 24">
						        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/></svg>
						    </symbol>
						</svg>
			  
          </div>
        </div>
        <div class="grid footerBottom">
          <div class="column width50 full475">
            <a href="<?php echo site_url(); ?>"><img src="<?php echo get_template_directory_uri() ?>/images/logo-white.svg" class="footerLogo" /></a> &copy; 2019 <a href="<?php echo site_url(); ?>">Kellie Hatch</a> - All rights reserved.
          </div>
        </div>		
  		</footer>
    </div><!-- end footerWrapper -->
	<script src="<?php echo get_template_directory_uri() ?>/scripts/script.js"></script>
    <script src="https://code.jquery.com/jquery-1.10.1.min.js"></script>
	</body>
</html>