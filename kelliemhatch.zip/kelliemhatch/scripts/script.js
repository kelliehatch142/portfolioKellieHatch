   //moblie nav
    $(document).ready(function(){
      $(".nav-button").click(function () {
      $(".nav-button,.primary-nav, .mobileLogo").toggleClass("open");
      });    
    });
  
//home scroll
  $(window).scroll(function() {
    $('#recentProjectCards').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+4200) {
        $(this).addClass("slideUp");
      }
    });
  });

//project pull up
  function isScrolledIntoView(elem) {
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}

$(window).scroll(function () {
    $('.deviceBackground').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('pullUp')
        }
    });

});




