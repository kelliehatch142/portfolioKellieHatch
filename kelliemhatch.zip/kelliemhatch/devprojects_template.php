<?php 
/* 
Template Name: Dev Projects Template
*/
?>
<?php get_header(); ?>
<style>
.webHeroImage { background: linear-gradient( rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.9) ), url("<?php echo get_template_directory_uri() ?>/images/webHero.jpg"); background-size:cover; background-repeat:no-repeat; background-position:center bottom; padding-left:10px; padding-right:10px; }

</style>
<div class="webHeroImage paddingTop125">
        <div class="webHeroCopy centerText fadeIn">
          <h1 class="serif">Where design and code ignite</h1>
          <p class="largeTxt1 topSpacing">I love taking a project through all the stages of production. From an idea to sketches to mock ups to development. Seeing the final product is my happy place.</p>
        </div>
      </div>
      <section class="maxWidth1000 topSpacing">
      <h2 class="serif colorBlock">Recent Web Projects</h2>
        <div class="grid topSpacing"> 
			
			
			
				  <?php 
		$posts = get_posts(array(
			'numberposts'	=> -1,
			'post_type'		=> 'webdev',
			'order' => 'DESC',
		
		));
		if( $posts ): ?>	
			  
			
			<?php foreach( $posts as $post ): 
				setup_postdata( $post );	
				?>
			  <?php $image = get_field('hero_img'); ?>
				<style>
					#project<?php the_ID()  ?> .projectOverlay { background:linear-gradient( rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7) ), url("<?php echo $image['url']; ?>"); background-size:cover; background-position:center center; } 
				</style>
	

			
			
			<div class="column width33 half767 full475 projectCards" id="project<?php the_ID()  ?>">
           		<div class="backgroundWhite">
					<a href="<?php the_permalink() ?>">
					<figure>
					  <img src="<?php echo $image['url']; ?>">
					</figure>
					<h3><?php the_title(); ?></h3>
					</a><a href="<?php the_permalink() ?>" class="projectLink">View Project</a>
				  </div>
              
				  <div class="projectOverlay projectOverlay6">
					<a href="<?php the_permalink() ?>" class="fullLink"></a>
					<div class="projectOverlayText">
					  <a href="<?php the_permalink() ?>" class="fullLink"></a>
					  <h3><?php the_title(); ?></h3>
					  <a href="<?php the_permalink() ?>" class="projectLink">View Project</a>
					</div> 
				  </div>
            </div>
			  
			 
				
			<?php endforeach; ?>
			<?php wp_reset_postdata(); ?>
			<?php endif; ?>
			
	


        </div>  
      </section>
<?php get_footer(); ?>