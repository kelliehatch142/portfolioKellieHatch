<?php 
/* 
Template Name: Contact Template
*/
?>
<?php get_header(); ?>
<style>
.aboutImage { background: linear-gradient( rgba(255, 255, 255, 0.6), rgba(255, 255, 255, 0.9) ), url("<?php echo get_template_directory_uri() ?>/images/aboutHero.jpg"); background-size:cover; background-repeat:no-repeat; background-position:center bottom; padding-left:10px; padding-right:10px; }
</style>
<div class="aboutImage paddingTop125">
        <div class="webHeroCopy centerText fadeIn">
          <h1 class="serif lineBlock">Get in touch</h1>
          <p class="largeTxt1 topSpacing">I would love to chat. Send me a message and let’s turn your idea into reality.</p>
        </div>
      </div>
      <section class="maxWidth1000 backgroundWhite">
		<h2 class="serif colorBlock largeTxt2 topPadding">Contact</h2>
		  <div class="topSpacing bottomPadding">
		  	<?php echo do_shortcode('[wpforms id="35" title="false" description="false"]'); ?>
		  </div>
      </section>
<?php get_footer(); ?>